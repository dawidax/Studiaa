public class Uzytkownik {
    public String imie;
    public String nazwisko;
    public String email;
    public String login;
    public String haslo;
}
