public class Film {
    private String tytul;
    private String gatunek;
    private double czasTrwania;
    private int rokWydania;
    private double ocena;

}
