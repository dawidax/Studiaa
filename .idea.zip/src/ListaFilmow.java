import javax.swing.*;

public class ListaFilmow {
    JFrame frame = new JFrame("Lista Filmów");
    JList<Film> list = new JList<>();
    DefaultListModel<Film> model = new DefaultListModel<>();

    JLabel label = new JLabel();
    JPanel panel = new JPanel();
    JSplitPane splitPane = new JSplitPane();
    public ListaFilmow(){
        list.setModel(model);
        model.addElement(new Film());
        splitPane.setLeftComponent(new JScrollPane(list));
        panel.add(label);
        splitPane.setRightComponent(panel);
        frame.add(splitPane);
        frame.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ListaFilmow::new);
    }
}
