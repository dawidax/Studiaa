import javax.swing.*;

public class Szukaj {
    private JButton listaDostępnychFilmówButton;
    private JButton znajdźFilmButton;
}
