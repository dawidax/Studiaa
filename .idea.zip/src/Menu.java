import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Menu {
    private JPanel Main;
    private JTextField txtNazwa;
    private JTextField txtCena;
    private JButton zapiszButton;
    private JButton usuńButton;
    private JButton zmieńButton;
    private JTextField txtId;
    private JTextField txtIlosc;
    private JButton szukajButton;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Menu().Main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
    public Menu() {
        Connect();

        zapiszButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String nazwa, cena, ilosc;

                nazwa = txtNazwa.getText();
                cena = txtCena.getText();
                ilosc = txtIlosc.getText();
                try {
                    st = con.prepareStatement("insert into produkty(nazwa, cena, ilosc) values (?,?,?)");
                    st.setString(1, nazwa);
                    st.setString(2, cena);
                    st.setString(3, ilosc);
                    st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "dodano!");

                    txtNazwa.setText("");
                    txtCena.setText("");
                    txtIlosc.setText("");
                    txtNazwa.requestFocus();
                }
                catch (SQLException e1) {
                    e1.printStackTrace();
                }

            }
        });
        szukajButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try{
                    String id = txtId.getText();

                    st = con.prepareStatement("select nazwa, cena, ilosc from produkty where id = ?");
                    st.setString(1, id);
                    ResultSet rs = st.executeQuery();

                    if(rs.next()==true)
                    {
                        String nazwa = rs.getString(1);
                        String cena = rs.getString(2);
                        String ilosc = rs.getString(3);

                        txtNazwa.setText(nazwa);
                        txtCena.setText(cena);
                        txtIlosc.setText(ilosc);
                    }
                    else
                    {
                        txtNazwa.setText("");
                        txtCena.setText("");
                        txtIlosc.setText("");
                        JOptionPane.showMessageDialog(null,"Zly kod id");
                    }
                }
                catch (SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
        zmieńButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String id,nazwa, cena, ilosc;

                nazwa = txtNazwa.getText();
                cena = txtCena.getText();
                ilosc = txtIlosc.getText();
                id = txtId.getText();
                try {
                    st = con.prepareStatement("update produkty set nazwa = ?, cena = ?, ilosc = ? where id = ?");
                    st.setString(1, nazwa);
                    st.setString(2, cena);
                    st.setString(3, ilosc);
                    st.setString(4, id);
                    st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "zaktualizowano!");

                    txtNazwa.setText("");
                    txtCena.setText("");
                    txtIlosc.setText("");
                    txtNazwa.requestFocus();
                    txtId.setText("");
                }
                catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        });
        usuńButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String pid;

                pid = txtId.getText();
                try{
                    st=con.prepareStatement("delete from produkty where id = ?");
                    st.setString(1, pid);
                    st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "usunięto!");

                    txtNazwa.setText("");
                    txtCena.setText("");
                    txtIlosc.setText("");
                    txtNazwa.requestFocus();
                    txtId.setText("");
                }
                catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        });
    }


    Connection con;
    PreparedStatement st;

    public void Connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/wypozyczalnia_filmow", "root","");
            System.out.println("Success");
        }
        catch (ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
        }
    }
}
